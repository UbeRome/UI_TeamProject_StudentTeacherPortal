//script for login (index.html)
